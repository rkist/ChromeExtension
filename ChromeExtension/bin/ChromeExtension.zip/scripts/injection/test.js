﻿
// this is the code which will be injected into a given page...

(function () {

    var p = document.createElement('p');
    var node = document.createTextNode('" + statusText + "');
    p.appendChild(node);

    var element = document.getElementById('status');
    element.appendChild(p);

})();