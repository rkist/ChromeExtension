﻿var msg = 'AAAAAAAAAAAAA';
console.log(msg);

msg = url
var p = document.createElement('p');
var node = document.createTextNode(msg);
p.appendChild(node);

var element = document.getElementById('status');
element.appendChild(p);


msg
