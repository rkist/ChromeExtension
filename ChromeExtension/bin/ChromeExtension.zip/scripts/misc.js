﻿function Log(msg)
{
    console.log("==========> " + msg);
}

